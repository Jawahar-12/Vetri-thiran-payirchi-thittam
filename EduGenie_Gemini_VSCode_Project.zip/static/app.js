const promptBox = document.getElementById("prompt");
const answerBox = document.getElementById("answer");
const sendButton = document.getElementById("send");

async function callApi(url, payload) {
    answerBox.textContent = "EduGenie is thinking... ✨";
    try {
        const response = await fetch(url, {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(payload)
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "Something went wrong.");
        answerBox.textContent = data.answer;
    } catch (error) {
        answerBox.textContent = "Error: " + error.message;
    }
}

sendButton.addEventListener("click", () => {
    const prompt = promptBox.value.trim();
    if (!prompt) {
        answerBox.textContent = "Please enter a question.";
        return;
    }
    callApi("/api/ask", {prompt});
});

document.querySelectorAll("[data-tool]").forEach(button => {
    button.addEventListener("click", () => {
        const text = promptBox.value.trim();
        if (!text) {
            answerBox.textContent = "First paste your study material in the box.";
            return;
        }
        callApi("/api/tool", {
            tool: button.dataset.tool,
            text
        });
    });
});

document.getElementById("copy").addEventListener("click", async () => {
    const text = answerBox.textContent;
    await navigator.clipboard.writeText(text);
});
