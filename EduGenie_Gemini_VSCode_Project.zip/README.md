# EduGenie 🎓
### Google Gemini Powered Learning Assistant

EduGenie is a beginner-friendly Generative AI project that uses Google's Gemini API to help students learn.

## Features
- 💬 AI Learning Chat
- 📝 Summarize study material
- 🧠 Generate quizzes
- 👨‍🏫 Explain difficult topics
- 📚 Create exam-oriented notes
- 🌐 Simple Flask web application
- 🔐 API key stored in `.env`

## Requirements
- Python 3.10+
- VS Code
- A Google Gemini API key

## 1. Open the project
Extract the ZIP and open the `EduGenie` folder in VS Code.

## 2. Create virtual environment

### Windows
```powershell
python -m venv .venv
.venv\Scripts\activate
```

If PowerShell blocks activation, use:
```powershell
.venv\Scripts\python.exe -m pip install -r requirements.txt
```

### macOS / Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
```

## 3. Install packages
```bash
pip install -r requirements.txt
```

## 4. Add Gemini API key
Create a file named `.env` in the project root.

Copy the contents of `.env.example` into `.env` and replace the placeholder:

```env
GEMINI_API_KEY=YOUR_REAL_API_KEY
GEMINI_MODEL=gemini-2.5-flash
```

Get your Gemini API key from Google AI Studio:
https://aistudio.google.com/apikey

Never upload your `.env` file to GitHub or share your API key.

## 5. Run EduGenie
```bash
python app.py
```

Open:
http://127.0.0.1:5000

## Project structure

```text
EduGenie/
│
├── app.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
│
├── templates/
│   └── index.html
│
└── static/
    ├── style.css
    └── app.js
```

## Troubleshooting

### "GEMINI_API_KEY is missing"
Make sure `.env` exists in the same folder as `app.py` and contains a valid key.

### Package error
Run:
```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### Port already in use
Change the final line in `app.py`:
```python
app.run(debug=True, host="127.0.0.1", port=5001)
```

## Academic project idea
For a college Generative AI project, you can extend EduGenie with:
- PDF upload and document Q&A
- Student progress tracking
- Flashcard generation
- Voice input
- Text-to-speech
- Login/signup
- Admin dashboard
- Database for saved notes and quizzes
