import os
from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv
from google import genai

load_dotenv()

app = Flask(__name__)

API_KEY = os.getenv("GEMINI_API_KEY")
MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

client = genai.Client(api_key=API_KEY) if API_KEY else None

SYSTEM_PROMPT = """You are EduGenie, a friendly AI learning assistant.
Help students understand concepts clearly and accurately.
Use simple language, examples, bullet points, and step-by-step explanations when useful.
For academic questions, encourage understanding rather than simply giving answers.
If the user asks for a quiz, create useful questions and provide answers separately when requested.
"""

def ask_gemini(prompt):
    if not client:
        raise RuntimeError("GEMINI_API_KEY is missing. Add it to the .env file.")
    response = client.models.generate_content(
        model=MODEL,
        contents=f"{SYSTEM_PROMPT}\n\nStudent request:\n{prompt}"
    )
    return response.text

@app.route("/")
def index():
    return render_template("index.html")

@app.post("/api/ask")
def ask():
    data = request.get_json(silent=True) or {}
    prompt = (data.get("prompt") or "").strip()
    if not prompt:
        return jsonify({"error": "Please enter a question."}), 400
    try:
        answer = ask_gemini(prompt)
        return jsonify({"answer": answer})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.post("/api/tool")
def tool():
    data = request.get_json(silent=True) or {}
    tool = data.get("tool", "")
    text = (data.get("text") or "").strip()

    prompts = {
        "summarize": f"Summarize the following study material into concise bullet points. Highlight key terms and important facts.\n\n{text}",
        "quiz": f"Create a 10-question quiz from the following study material. Mix MCQ and short-answer questions. Put the answer key at the end.\n\n{text}",
        "explain": f"Explain the following topic like a teacher explaining it to a beginner. Include a simple example and a short recap.\n\n{text}",
        "notes": f"Turn the following study material into clean exam-oriented notes with headings, subheadings, key points, and important definitions.\n\n{text}"
    }

    if tool not in prompts:
        return jsonify({"error": "Unknown tool."}), 400
    if not text:
        return jsonify({"error": "Please enter study material first."}), 400

    try:
        return jsonify({"answer": ask_gemini(prompts[tool])})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)
